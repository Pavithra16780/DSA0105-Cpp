// INTERACTIVE QUIZ SYSTEM
// Module 1: Question Bank Management
// Module 2: Quiz Execution
// Module 3: Scoring, Evaluation & Report Generation

#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Structure Definition
struct Question {
    string text;
    string options[4];
    int correct;   // 0=A, 1=B, 2=C, 3=D
};

//====================================================
// MODULE 1 : QUESTION BANK MANAGEMENT
//====================================================

// Add Question
void addQuestion(vector<Question>& bank) {

    Question q;

    cin.ignore();

    cout << "\nEnter Question: ";
    getline(cin, q.text);

    for(int i = 0; i < 4; i++) {
        cout << "Enter Option "
             << char('A' + i) << ": ";
        getline(cin, q.options[i]);
    }

    cout << "Enter Correct Option (1-4): ";
    cin >> q.correct;

    q.correct--;

    if(q.correct < 0 || q.correct > 3) {
        cout << "Invalid Correct Option!\n";
        return;
    }

    bank.push_back(q);

    cout << "Question Added Successfully.\n";
}

// View Questions
void displayQuestions(const vector<Question>& bank) {

    cout << "\n===== QUESTION BANK =====\n";

    if(bank.empty()) {
        cout << "No Questions Available.\n";
        return;
    }

    for(int i = 0; i < bank.size(); i++) {

        cout << "\nQuestion "
             << i + 1 << ": "
             << bank[i].text << endl;
    }
}

// Delete Question
void deleteQuestion(vector<Question>& bank) {

    if(bank.empty()) {
        cout << "\nQuestion Bank is Empty.\n";
        return;
    }

    displayQuestions(bank);

    int num;

    cout << "\nEnter Question Number to Delete: ";
    cin >> num;

    if(num < 1 || num > bank.size()) {
        cout << "Invalid Question Number.\n";
        return;
    }

    bank.erase(bank.begin() + num - 1);

    cout << "Question Deleted Successfully.\n";
}

//====================================================
// MODULE 2 : QUIZ EXECUTION
//====================================================

inline int askQuestion(const Question& q,
                       int number) {

    cout << "\n--------------------------------";
    cout << "\nQ" << number
         << ". " << q.text << endl;

    for(int i=0; i<4; i++) {

        cout << char('A'+i)
             << ") "
             << q.options[i]
             << endl;
    }

    int answer;

    cout << "Your Answer (1-4): ";
    cin >> answer;

    return answer - 1;
}

//====================================================
// MODULE 3 : SCORING & REPORT GENERATION
//====================================================

inline double calculatePercentage(
    int score,
    int total) {

    return total == 0
           ? 0
           : (score * 100.0) / total;
}

inline string evaluateResult(
    double percentage) {

    return percentage >= 50
           ? "PASS"
           : "NEEDS IMPROVEMENT";
}

void generateReport(const string& name,
                    const vector<Question>& bank,
                    const vector<int>& answers) {

    int score = 0;
    int correctCount = 0;
    int wrongCount = 0;

    for(int i = 0; i < bank.size(); i++) {

        if(answers[i] == bank[i].correct) {
            score++;
            correctCount++;
        }
        else {
            wrongCount++;
        }
    }

    double percentage =
        calculatePercentage(
            score,
            bank.size()
        );

    cout << "\n\n================================";
    cout << "\n         QUIZ REPORT";
    cout << "\n================================";

    cout << "\nStudent Name      : "
         << name;

    cout << "\nTotal Questions   : "
         << bank.size();

    cout << "\nCorrect Answers   : "
         << correctCount;

    cout << "\nWrong Answers     : "
         << wrongCount;

    cout << "\nScore             : "
         << score
         << "/" << bank.size();

    cout << "\nPercentage        : "
         << percentage
         << "%";

    cout << "\nResult            : "
         << evaluateResult(percentage);

    cout << "\n\n===== ANSWER ANALYSIS =====\n";

    for(int i = 0; i < bank.size(); i++) {

        cout << "\nQ" << i + 1
             << ". "
             << bank[i].text
             << endl;

        char userAnswer =
            (answers[i] >= 0 &&
             answers[i] <= 3)
            ? char('A' + answers[i])
            : '-';

        char correctAnswer =
            char('A' + bank[i].correct);

        cout << "Your Answer    : "
             << userAnswer
             << endl;

        cout << "Correct Answer : "
             << correctAnswer
             << endl;

        if(answers[i] ==
           bank[i].correct)

            cout << "Status         : "
                 << "CORRECT"
                 << endl;

        else

            cout << "Status         : "
                 << "WRONG"
                 << endl;
    }

    cout << "================================\n";
}

//====================================================
// MAIN FUNCTION
//====================================================

int main() {

    vector<Question> bank = {

        {
          "Which function is the entry point of a C++ program?",
          {"start()", "main()", "begin()", "run()"},
          1
        },

        {
          "Which keyword requests an inline function?",
          {"static", "friend", "inline", "virtual"},
          2
        },

        {
          "Which symbol ends most C++ statements?",
          {";", ":", ".", ","},
          0
        }
    };

    string studentName;

    cout << "================================\n";
    cout << "     INTERACTIVE QUIZ SYSTEM\n";
    cout << "================================\n";

    cout << "Enter Student Name: ";
    getline(cin, studentName);

    int choice;

    do {

        cout << "\n\n========== MENU ==========\n";

        cout << "1. Add Question\n";
        cout << "2. View Question Bank\n";
        cout << "3. Delete Question\n";
        cout << "4. Start Quiz\n";
        cout << "5. Exit\n";

        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice) {

        case 1:
            addQuestion(bank);
            break;

        case 2:
            displayQuestions(bank);
            break;

        case 3:
            deleteQuestion(bank);
            break;

        case 4: {

            if(bank.empty()) {

                cout << "\nQuestion Bank Empty.\n";
                break;
            }

            vector<int> answers;

            for(int i=0;
                i<bank.size();
                i++) {

                answers.push_back(
                    askQuestion(
                        bank[i],
                        i + 1
                    )
                );
            }

            generateReport(
                studentName,
                bank,
                answers
            );

            break;
        }

        case 5:
            cout << "\nThank You for Using the Quiz System.\n";
            break;

        default:
            cout << "\nInvalid Choice.\n";
        }

    } while(choice != 5);

    return 0;
}
